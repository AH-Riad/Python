clc;
clear all;
close all;

t = 0:1:100;
f = 20;
fs = 100;
x = 4*sin(2*pi*f/fs*t);

subplot(2,2,1);
plot(t,x);
ylabel('amplitude');
xlabel('time');
title('1st signal');

f1 = 40;
z = 3*sin(2*pi*f1/fs*t);

subplot(2,2,2);
plot(t,z);   
ylabel('amplitude');
xlabel('time');
title('2nd signal');
add = x + z;

subplot(2,2,3);
plot(t,add);
ylabel('amplitude');
xlabel('time');
title('add');


N = length(add);
y = zeros(1,N);

for k = 1:N
    for n = 1:N
        y(k) = y(k) + add(n) * exp(-1j*2*pi*(k-1)*(n-1)/N);
    end
end
magnitude = abs(y);
t_freq = 0:(N/2)-1;
magnitudes = magnitude(1:N/2);   

subplot(2,2,4);
plot(t_freq, magnitudes);
ylabel('amplitude');
xlabel('frequency index');
title('FFT of Added Signal');

