clc;
clear all;
close all;
t=0:1:100;
f=20;
fs=100;
x= 4*sin(2*pi*f/fs*t);

subplot(2,1,1);
stem(t,x);
ylabel('amplitude');
xlabel('time');
title('input');

    N = length(x);                  
%X_dft = zeros(1, N);            

for k = 1:N
    y(k) = 0;
    for n = 1:N
        y(k) = y(k)+x(n) * exp(-1j*2*pi*(k-1)*(n-1)/N);
    end
end
magnitude = abs(y);
t=0:(N/2)-1;
magnitudes=magnitude(1:50);
subplot(2,1,2)
stem(t,magnitudes);
ylabel('amplitude');
xlabel('time');
title('fft');