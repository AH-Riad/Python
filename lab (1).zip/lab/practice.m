clc;
clear all;
close all;
t1=-3:1:3;
x=(t1==0);
%figure
subplot(2,3,1);
stem(t1,x);
grid on;
xlabel("Time");
ylabel("Amplitude");
title("Unite impuls signal");

%unite step signal:
t2=-5:1:10;
x2=[zeros(1,5),ones(1,11)];
subplot(2,3,2);
stem(t2,x2);
grid on;
xlabel("Time");
ylabel("Amplitude");
title("Unite step signal");

%exponential signal:
a=5;
t3=-10:1:10;
x3=exp(a*t3);
subplot(2,3,3);
stem(t3,x3);
grid on;
xlabel("Time");
ylabel("Amplitude");
title("Exponential signal");

%ramp signal:
t4=-10:1:20;
x4 = t4 .* (t4 >= 0); 
subplot(2,3,4);
stem(t4,x4,"filled");
grid on;
xlabel("Time");
ylabel("Amplitude");
title("Ramp signal");

%sinusoidal signal:
f=10;
t5=-10:1:10;
x5=5*sin(2*pi*f*t5);
subplot(2,3,5);
stem(t5,x5,"filled");
grid on;
xlabel("Time");
ylabel("Amplitude");
title("Sinusoidal signal");

 %RANDOM SIGNAL
 t6=-10:1:20;
 x6=rand(1,31);
 subplot(2,3,6);
 stem(t6,x6);
 xlabel('time');
 ylabel('Amplitude');
 title('Random signal')



